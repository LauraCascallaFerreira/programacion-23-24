package trimestre2.examen2Programacion;

import java.util.Arrays;

/*Genera un array de 50 posiciones FLOTANTES que tomarán valores entre -100 y 100. 
Separe en dos matrices los valores positivos y negativos. Ordene ambos arrays por el 
método Merge Sort.

Considere el cero positivo. A continuación, separe el array de positivos en dos arrays, 
uno de pares y otro de impares (use casteo); muestre ambos.
 */
public class ejercicio01A {

    //DOS PUNTOS

    public static void rellenarArray(float arr[]){
        for(int i=0; i<arr.length; i ++){
            arr[i]=(float)(-100+Math.random()*200);
        }
        System.out.println(Arrays.toString(arr));
    }

    public static void main(String[] args) {
        float arr[] = new float[50];
        rellenarArray(arr);
        int positivo=0;
        int negativo=0;

        for(int i=0; i<arr.length; i++){
            if(arr[i]>0){
                positivo++;
            } else {
                negativo++;
            }
        }
        float positivos[] = new float[positivo];
        float negativos[] = new float[negativo];

        int posicionesp=0;
        int posicionesn=0;

        for(int i=0; i<arr.length; i++){
            if(arr[i]>0){
                positivos[posicionesp]=arr[i];
                posicionesp++;
            } else {
                negativos[posicionesn]=arr[i];
                posicionesn++;
            }
        }

        System.out.println("Numeros positivos:");
        mergeSort(positivos);
        System.out.println(Arrays.toString(positivos));
        System.out.println("Numeros negativos:");
        mergeSort(negativos);
        System.out.println(Arrays.toString(negativos));
    }

    //CREO QUE ME FALTA POR AJUSTAR ALGO CON EL FLOAT EN EL METODO DE ORDENACION

    public static float[] mergeSort(float[] positivos){

	    if(positivos.length > 1){
		    int elementsInA1 = positivos.length / 2;
		    int elementsInA2 = positivos.length - elementsInA1;
		    float arr1[] = new float[elementsInA1];
		    float arr2[] = new float[elementsInA2];

		    for(int i = 0; i < elementsInA1; i++)
			    arr1[i] = positivos[i];

		    for(int i = elementsInA1; i < elementsInA1 + elementsInA2; i++)
			    arr2[i - elementsInA1] = (int) positivos[i];
		        
		        arr1 = mergeSort(arr1);
		        arr2 = mergeSort(arr2);
		
		    int i = 0, j = 0, k = 0;
        	while(arr1.length != j && arr2.length != k){
			    if(arr1[j] < arr2[k]){
				    positivos[i] = arr1[j];
				    i++;
				    j++;
			    } else {
				    positivos[i] = arr2[k];
				    i++;
				    k++;}
		    }

		    while(arr1.length != j){
			    positivos[i] = arr1[j];
			    i++;
			    j++;
		    }

		    while(arr2.length != k){
			    positivos[i] = arr2[k];
			    i++;
			    k++;
		    }
	    }
	    return positivos;
    }
    
}
