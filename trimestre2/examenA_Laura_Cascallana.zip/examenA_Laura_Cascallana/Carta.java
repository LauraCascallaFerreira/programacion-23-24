package trimestre2.examen2Programacion;

import java.util.Objects;

import trimestre2.arraylist.ejercicios.carta;

public class Carta implements Comparable{

    String palo;
    int valor;

    static final String[] side = {"oros", "copas", "espadas", "bastos"};
    
    Carta(){
        this.palo = side[(int) (Math.random()*4)];
    }

    public String getPalo() {
        return palo;
    }

    public void setPalo(String palo) {
        this.palo = palo;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public static String[] getSide() {
        return side;
    }

    

    @Override
    public String toString() {
        return "carta [palo=" + palo + ", valor=" + valor + "]";
    }

    @Override
    public int hashCode() {
        return Objects.hash(palo, valor);
    }

    @Override
    public boolean equals(Object obj) {
        //si los dos objetos son el mismo:true
        if (this == obj)
            return true;
        //si el objeto que le pasas es nulo:false
        if (obj == null)
            return false;
        //si la clase del objeto al que llama no coincide con la clase que le pasas:false
        if (getClass() != obj.getClass())
            return false;
        carta otra = (carta) obj;
        return Objects.equals(palo, otra.getPalo())&&Objects.equals(valor, otra.getValor());
    }

    @Override
    public int compareTo(Object o) {
        carta c = (carta) o;
        return this.getPalo().compareTo(c.getPalo());
    }

    
}
    

