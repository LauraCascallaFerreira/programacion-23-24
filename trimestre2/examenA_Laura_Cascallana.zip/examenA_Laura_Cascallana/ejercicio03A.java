package trimestre2.examen2Programacion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

/*
 */
public class ejercicio03A {

    //DOS PUNTOS Y MEDIO

    /*
    Con la clases carta y mano de 6 cartas del material del trimestre utilice un 
HashMap para contabilizar la puntuación según el siguiente criterio para cada carta:

Oros 1 punto Copas 5 puntos Espadas 10 puntos Bastos 20 puntos
    Prepare un menú que permita

    1 generar y mostrar el resultado de la mano por pantalla
    2 guardar la mano en un fichero
    3 recuperar la mano desde un fichero
    4 salir
    */

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<Carta> mano = new ArrayList<>();
        HashMap<String, Integer> valoresCartas = new HashMap<>();
        valoresCartas.put("oros", 1);
        valoresCartas.put("copas", 5);
        valoresCartas.put("espadas", 10);
        valoresCartas.put("bastos", 20);

        char opcion=' ';

        if(opcion!='d'){

            System.out.println("Selecciona una opción:");
            System.out.println("a.generar mano");
            System.out.println("b.guardar mano");
            System.out.println("c.recuperar mano");

            opcion=sc.next().charAt(0);

            switch (opcion) {
                case 'a':
                    generarMano(mano, valoresCartas);
                break;
                case 'd':
                    System.out.println("Saliento del programa.");
                break;
                default:
                    System.out.println("No has introducido correctamente la opción.");
            }
        }
        
         
        
    }

    public static void generarMano(ArrayList<Carta>mano, HashMap<String, Integer> valoresCartas ){
        while (mano.size() < 6) {
            Carta nuevaCarta = new Carta();
            if (!mano.contains(nuevaCarta)) {
                mano.add(nuevaCarta);
            }
        }

        System.out.println("Mano de cartas ordenadas por PALO y NÚMERO:");
        for (Carta carta : mano) {
            System.out.println(carta.getValor() + " de " + carta.getPalo());
        }

        int totalPuntos = calcularTotalPuntos(mano, valoresCartas);
        System.out.println("\nTotal de puntos de la mano: " + totalPuntos);
    }

    public static int calcularTotalPuntos(ArrayList<Carta> mano, HashMap<String, Integer> valores) {
        int total = 0;
        for (Carta carta : mano) {
            if (valores.containsKey(carta.getValor())) {
                total += valores.get(carta.getValor());
            } else {
                total += Integer.parseInt(carta.getValor());
            }
        }
        return total;
    }
}
