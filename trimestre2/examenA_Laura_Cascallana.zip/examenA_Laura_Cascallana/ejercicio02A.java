package trimestre2.examen2Programacion;

import java.util.Scanner;

/*Un grupo de inteligencia militar desea codificar los mensajes secretos de tal forma 
que no puedan ser interpretados con una lectura directa, para lo cual han establecido 
las siguientes reglas: 
a) Todo mensaje debe estar sus letras en mayúsculas. 
b) Reemplazar cada letra por la que sigue dos posiciones después según abecedario, 
excepto Y que se deberá reemplazar con la letra A y Z por B. 
c) Reemplazar cada dígito encontrado por el número que le sigue dos posiciones 
después excepto el 8 que deberá ser reemplazado por el 0 y el 9 por el 1.

Pida una cadena al usuario (conteniendo letras mayusculas y minusculas y digitos) y 
muestrela codificada con las anteriores reglas.
 */
public class ejercicio02A {

    //DOS PUNTOS

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dame una frase para codificarla en mayusculas:");
        String frase = sc.nextLine();
        String fraseMayus=frase.toUpperCase();
        

        String reemplazo="";

        for(int i=0; i<fraseMayus.length(); i++){

            if(fraseMayus.charAt(i)=='B'){
                reemplazo=fraseMayus.replace('B', 'Z');
            } else if(fraseMayus.charAt(i)=='Y'){
                reemplazo=fraseMayus.replace('Y', 'A');
            } 

            if(fraseMayus.charAt(i)=='8'){
                reemplazo=fraseMayus.replace('8', '0');
            } else if(fraseMayus.charAt(i)=='9'){
                reemplazo=fraseMayus.replace('9', '1');
            }
        }

        System.out.println(reemplazo);
    }
    
}
