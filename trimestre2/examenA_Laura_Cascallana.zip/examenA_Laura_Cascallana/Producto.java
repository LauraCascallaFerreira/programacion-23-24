package trimestre2.examen2Programacion;

public class Producto {

    String nombre;
    int cantidad;
    double precio;

    public Producto(String nombre, int cantidad, double precio) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
    }
}
