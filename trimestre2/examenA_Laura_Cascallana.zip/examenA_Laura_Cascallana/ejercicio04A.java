package trimestre2.examen2Programacion;

import java.util.ArrayList;

/*Utilizando la clase Producto un supermercado nos pide que hagamos una pequeña 
aplicación que almacene los productos pasados por el escaner de la caja central.

La aplicación debe almacenar Productos (crea la clase), cada producto al crearse 
contiene una cantidad(entera), un precio (flotante). Ambos dos generados aleatoriamente. 

El nombre del producto será básico (producto1, producto2, producto3, etc.).

Calcular el precio total de una lista de entre 1 y 8 productos (aleatorio). Dichos 
productos serán almacenados en una lista dinámica.

Mostrar un ticket con todo lo vendido y el precio final como se hacen en los 
supermercados.

***********Cantidad****Precio*****Total
Producto1 		5 	 3.5 		17.5
Producto2    	7	 2.5 		17.5

Precio 		35
			iva 10%		3.5
			
Total			38.5
 */
public class ejercicio04A {

    //DOS PUNTOS Y MEDIO

    public static void main(String[] args) {

		ArrayList<Producto> productos = new ArrayList<>();

        int compra = (int)(1+Math.random()*8);

        for (int i = 1; i <= compra; i++) {

            String nombre = "Producto " + i;

            int cantidad = (int)(1+Math.random()*10); 
            double precio = (1+Math.random()*20); 

            productos.add(new Producto(nombre, cantidad, precio));
        }

        float total = calcularTotal(productos);

        
        System.out.println("Ticket de compra:");
		System.out.println("***********Cantidad****Precio*****Total");
        for (Producto producto : productos) {
            System.out.println(producto.nombre + "     " + producto.cantidad + "         " + producto.precio);
        }
		
		System.out.println();
        System.out.println("Total: " + total);
		
	}

	public static float calcularTotal(ArrayList<Producto> productos) {
        float total = 0;
        for (Producto producto : productos) {
            double IVA=(producto.cantidad*producto.precio)*10;
            total += (producto.cantidad * producto.precio)-IVA;
        }
        return total;
    }
	
}
